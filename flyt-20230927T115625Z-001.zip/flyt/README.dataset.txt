# flyt > 2023-09-24 1:06am
https://universe.roboflow.com/college-tbzln/flyt

Provided by a Roboflow user
License: MIT

